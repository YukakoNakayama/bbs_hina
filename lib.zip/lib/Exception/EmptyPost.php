<?php
​
namespace Bbs\Exception;
​
class EmptyPost extends \Exception {

}



?>